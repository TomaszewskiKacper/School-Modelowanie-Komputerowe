var searchData=
[
  ['g_0',['g',['../classsf_1_1Color.html#a591daf9c3c55dea830c76c962d6ba1a5',1,'sf::Color']]],
  ['green_1',['Green',['../classsf_1_1Color.html#a95629b30de8c6856aa7d3afed12eb865',1,'sf::Color']]]
];
