var searchData=
[
  ['encode_0',['encode',['../classsf_1_1Utf_3_018_01_4.html#a5fbc6b5a996f52e9e4a14633d0d71847',1,'sf::Utf&lt; 8 &gt;::encode()'],['../classsf_1_1Utf_3_0116_01_4.html#a516090c84ceec2cfde0a13b6148363bb',1,'sf::Utf&lt; 16 &gt;::encode()'],['../classsf_1_1Utf_3_0132_01_4.html#a27b9d3f3fc49a8c88d91966889fcfca1',1,'sf::Utf&lt; 32 &gt;::encode(Uint32 input, Out output, Uint32 replacement=0)']]],
  ['encodeansi_1',['encodeAnsi',['../classsf_1_1Utf_3_0132_01_4.html#af6590226a071076ca22d818573a16ded',1,'sf::Utf&lt; 32 &gt;']]],
  ['encodewide_2',['encodeWide',['../classsf_1_1Utf_3_0132_01_4.html#a52e511e74ddc5df1bbf18f910193bc47',1,'sf::Utf&lt; 32 &gt;']]],
  ['end_3',['end',['../classsf_1_1String.html#ac823012f39cb6f61100418876e99d53b',1,'sf::String::end()'],['../classsf_1_1String.html#af1ab4c82ff2bdfb6903b4b1bb78a8e5c',1,'sf::String::end() const']]],
  ['endofpacket_4',['endOfPacket',['../classsf_1_1Packet.html#a61e354fa670da053907c14b738839560',1,'sf::Packet']]],
  ['erase_5',['erase',['../classsf_1_1String.html#aaa78a0a46b3fbe200a4ccdedc326eb93',1,'sf::String']]]
];
